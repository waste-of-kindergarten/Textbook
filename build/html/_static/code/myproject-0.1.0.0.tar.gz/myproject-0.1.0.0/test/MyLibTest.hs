module Main (main) where

import Fac
import Test.HUnit
import System.Exit 

tests :: Test
tests = TestList
  [ "Test 1" ~: assertEqual "run smoothly x > 0" 120 (factorial 5),
    "Test 2" ~: assertEqual "run smoothly x = 0" 1 (factorial 0) ]

main :: IO ()
main = do 
  counts <- runTestTT tests
  if errors counts == 0 && failures counts == 0 
    then exitSuccess
    else exitFailure
