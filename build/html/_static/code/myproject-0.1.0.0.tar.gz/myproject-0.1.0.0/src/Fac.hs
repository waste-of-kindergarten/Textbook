
module Fac (factorial) where 

factorial :: Integer -> Integer 
factorial x = if x < 0 
                then error " x < 0 not allowed"
                else fun x

fun :: Integer -> Integer 
fun 0 = 1 
fun x = x * fun (x - 1)
